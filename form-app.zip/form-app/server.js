const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');

const app = express();
const db = new sqlite3.Database('./form.db');

app.use(bodyParser.json());
app.use(express.static('.')); // Serve static files

// Handle form submission
app.post('/submit', (req, res) => {
  const { name, email, message } = req.body;
  
  db.run(
    'INSERT INTO form_data (name, email, message) VALUES (?, ?, ?)',
    [name, email, message],
    function(err) {
      if (err) {
        return res.status(500).send('Error saving to database');
      }
      res.send('Form submitted successfully!');
    }
  );
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});