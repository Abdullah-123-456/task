const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./form.db');

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS form_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    message TEXT
  )`);

  console.log('✅ Database and table created successfully.');
});

db.close();
